The code for this project was run in the following format
    python3 project1a_main.py [reference genome] [reads]

For the results on Codalab, I ran
    python3 project1a_main.py project1a_10000_reference_genome.fasta project1a_10000_with_error_paired_reads.fasta